# Contributing to Comp-Lens

Thanks for contributing. This guide covers local setup, the quality gates your
change must pass, and how to get it reviewed.

## Local setup

Requires Python 3.11+.

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# environment (see app/config.py for the full list)
export APP_ENV=development
export DATABASE_URL="sqlite+pysqlite:////tmp/complens.db"
export COMP_LENS_SECRET_KEY=dev-secret

# build the schema, then run
alembic upgrade head
uvicorn app.main:app --reload
```

The dashboard is served at `/dashboard`.

## Before you open a PR

Your change must pass the same two gates CI runs (`.github/workflows/ci.yml`):

```bash
# 1. Lint — must be clean
pip install ruff==0.15.20
ruff check .

# 2. Tests — must all pass
APP_ENV=test COMP_LENS_SECRET_KEY=test \
  DATABASE_URL="sqlite+pysqlite:////tmp/test.db" \
  pytest -q -p no:randomly
```

Both are **blocking** — a PR that fails either will not be merged.

## Coding standards

- **Lint config lives in `pyproject.toml`.** The ruff rule set is intentionally
  scoped: it catches dead code, unused imports, and ambiguous names, but allows
  two patterns this codebase uses on purpose — late/in-function imports (to
  avoid circular imports between `app.main`, the service layer, and models) and
  dense single-line compound statements in render/serialization helpers. Don't
  reformat those wholesale.
- **Layering.** Keep the direction `main → services → models/connectors`.
  Business logic goes in `app/services/`, not in route handlers.
- **Migrations.** Any model change needs an Alembic migration
  (`alembic revision -m "..."`). The chain must have a single head and apply
  cleanly from scratch (`alembic upgrade head` on an empty DB).
- **Tests.** New behavior needs a test. Prefer the isolated `fresh_db` /
  `db_session` fixtures in `tests/conftest.py` for new tests; the older
  per-module shared-file fixtures still work but are not the pattern to copy.
- **SQLite gotcha.** SQLite returns naive datetimes; use the `_aware()` helper
  pattern before comparing against `utc_now()` to avoid tz-aware/naive errors.
- **Security.** Any new outbound fetch must route through the SSRF guard. Never
  log or persist secrets. See `SECURITY.md`.

## Honesty rule

Comp-Lens deliberately distinguishes **live** functionality from **demo**
content. If a feature isn't wired to a real backend, gate it behind demo mode
or label it — don't present illustrative data as live. UI actions should call
real endpoints, not fake success with a toast.

## Commit & PR

- Use clear, conventional-style messages (`feat:`, `fix:`, `test:`, `docs:`,
  `chore:`).
- Keep PRs focused. Fill in the PR template.
- A maintainer review is required before merge (see `CODEOWNERS`).
