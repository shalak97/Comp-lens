# Repo maturity upgrade — how to apply

All changes verified: `ruff check .` clean, 240 tests pass, migrations apply
from scratch (single head). Nothing here changes runtime behavior.

## 1. Copy the new files into the repo root (preserving paths)

- `.github/workflows/ci.yml`      ← the real CI gate (lint + tests, blocking)
- `pyproject.toml`                ← ruff + pytest config
- `tests/conftest.py`             ← shared fixtures / env defaults
- `SECURITY.md`, `CONTRIBUTING.md`, `CHANGELOG.md`
- `.github/CODEOWNERS`
- `.github/pull_request_template.md`
- `.github/ISSUE_TEMPLATE/*`

## 2. Apply the lint fixes

    git apply lint-fixes.patch

(These are unused-import/variable removals and two `l`→`lane` renames — no
behavior change. If the patch doesn't apply cleanly because your tree differs,
just run `pip install ruff==0.15.20 && ruff check . --fix` and fix the handful
of remaining items by hand; the config in `pyproject.toml` defines the rules.)

## 3. Delete the broken workflow (must be done on the remote)

`.github/workflows/deploy patches.yml` contains a raw git diff, not YAML. It is
the source of the failing Actions runs. Remove it:

    git rm ".github/workflows/deploy patches.yml"

## 4. Commit from a working tree (not the web-UI "upload files" flow)

    git checkout -b chore/repo-maturity
    git add .github pyproject.toml tests/conftest.py SECURITY.md CONTRIBUTING.md CHANGELOG.md
    git commit -m "chore: add CI (ruff+pytest), lint config, governance docs; remove broken workflow"
    git push -u origin chore/repo-maturity
    # then open a PR — CI will run on it

## What I could not do for you

- **Push / delete on the remote** — my environment only edits a local working
  copy. Steps 3 and 4 are yours.
- **Branch/PR workflow adoption** — that's a GitHub repo-settings + habit change
  (enable "require status checks" and "require PR review" on `main` so this CI
  actually gates merges).
- **Dependency pinning** — you chose to skip it. When ready, the reproducible
  path is `pip-compile` → `requirements.lock` and install that in CI.
