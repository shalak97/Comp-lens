# Security Policy

Comp-Lens is a compliance and trust-telemetry platform, so we hold its own
security to the standard it audits for.

## Reporting a vulnerability

**Please do not open a public GitHub issue for security vulnerabilities.**

Instead, report privately using GitHub's built-in
[private vulnerability reporting](https://docs.github.com/en/code-security/security-advisories/guidance-on-reporting-and-writing-information-about-vulnerabilities/privately-reporting-a-security-vulnerability):
open the repository's **Security** tab → **Report a vulnerability**.

When reporting, please include:

- a description of the vulnerability and its impact;
- the affected component (connector, API route, policy engine, crawler, etc.);
- steps to reproduce, ideally a minimal proof of concept;
- any suggested remediation.

We aim to acknowledge reports within **3 business days** and to provide a
remediation timeline after initial triage.

## Supported versions

This project is pre-1.0. Security fixes are applied to the `main` branch only;
there is no backport guarantee for earlier states.

## Security model (what to keep in mind when testing)

Comp-Lens has several deliberate security boundaries. Findings that show any of
these boundaries can be bypassed are in scope:

- **Authentication / tenancy.** API routes require an API key
  (`COMP_LENS_API_KEYS`) and are tenant-scoped via `authorize_tenant`. In
  production the API *fails closed* — with no keys configured it refuses
  requests rather than granting anonymous access.
- **SSRF protection.** All outbound fetches (document ingestion, the crawler,
  connector HTTP) route through a guard (`_assert_safe` / `assert_safe_url`)
  that resolves and blocks private, loopback, link-local, reserved, and
  cloud-metadata addresses on every redirect hop. The crawler additionally
  pins each target to its registered domain and honours robots.txt.
- **Secret handling.** Secrets come only from environment variables
  (`COMP_LENS_SECRET_KEY`, connector credentials). Connector credentials are
  encrypted at rest; browser-stored local credentials are AES-GCM encrypted
  with a user passphrase and never leave the device in plaintext.
- **Policy sandbox.** The policy-as-code evaluator uses an AST allowlist
  (`SafeEvaluator`) with no arbitrary code execution.

## Out of scope

- Findings that require a misconfigured deployment we explicitly warn about at
  boot (e.g. running in production with `COMP_LENS_API_KEYS` unset — the app
  logs an error and refuses requests by design).
- The bundled demo dataset and the illustrative graph views, which are clearly
  labelled as non-production sample content.
