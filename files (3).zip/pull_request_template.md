## What & why

<!-- What does this change do, and why? Link any related issue. -->

## Type of change

- [ ] Bug fix
- [ ] New feature
- [ ] Refactor / cleanup
- [ ] Docs / governance
- [ ] CI / tooling

## Checklist

- [ ] `ruff check .` passes
- [ ] `pytest -q -p no:randomly` passes (all tests green)
- [ ] Model changes include an Alembic migration; `alembic upgrade head` applies cleanly from an empty DB and the chain has a single head
- [ ] New behavior has tests (prefer the `fresh_db` / `db_session` fixtures)
- [ ] Any new outbound fetch routes through the SSRF guard
- [ ] No secrets logged or committed
- [ ] Live vs demo: new UI actions call real endpoints (not fake-success toasts); illustrative data is labelled or demo-gated

## Notes for reviewers

<!-- Anything that needs extra attention, trade-offs made, follow-ups deferred. -->
