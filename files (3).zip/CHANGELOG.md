# Changelog

All notable changes to Comp-Lens are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and the project uses
date-based entries while pre-1.0.

## [Unreleased]

### Added
- **Continuous integration** (`.github/workflows/ci.yml`): a real CI gate that
  runs `ruff` lint and the full `pytest` suite on every push and pull request,
  blocking merge on failure. (Previously the only workflows were one-shot code
  scaffolding jobs; nothing verified the codebase on push.)
- **Lint configuration** in `pyproject.toml` — a ruff rule set tuned to this
  codebase's intentional patterns.
- **Shared test configuration** (`tests/conftest.py`) with isolated `fresh_db`
  / `db_session` fixtures and centralized environment defaults, reducing the
  test-ordering fragility caused by shared on-disk SQLite files.
- Governance docs: `SECURITY.md`, `CONTRIBUTING.md`, `CODEOWNERS`, this
  changelog, and PR/issue templates.

### Changed
- Cleaned all real lint violations (unused imports/variables, ambiguous names,
  multiple-imports-per-line) across `app/` and `tests/`. No behavioral change.

### Fixed
- Removed dead local variables in `ai_governance`, `attestation`, and
  `resolver` services.

### Known issues
- `.github/workflows/deploy patches.yml` contains a raw `git diff` instead of
  workflow YAML and fails to parse on every push. It must be deleted from the
  remote (it is not a real workflow). See the repository notes.
